# Plataformas y Consolas

## Cómo elegir

La **plataforma** determina dónde se ejecutará el videojuego y condiciona controles, rendimiento, interfaz, resolución, distribución y almacenamiento.

Elige la plataforma según las necesidades reales del proyecto, no simplemente porque sea popular.

## PC

Computadoras personales.

**Características habituales:**
- Teclado y mouse.
- Controladores.
- Amplia variedad de hardware.
- Diferentes resoluciones y configuraciones.

**Considerar:** optimización para diferentes equipos y configuraciones gráficas.

## Nintendo Switch

Consola híbrida portátil y de sobremesa.

**Considerar:** controles, modo portátil, resolución, rendimiento y restricciones específicas de la plataforma.

## PlayStation

Familia de consolas de Sony.

**Ejemplos de plataformas:** PlayStation 4, PlayStation 5.

**Considerar:** control con gamepad, certificación, rendimiento y requisitos de publicación.

## Xbox

Familia de consolas de Microsoft.

**Ejemplos:** Xbox One, Xbox Series X|S.

**Considerar:** control con gamepad, rendimiento y requisitos de publicación.

## Steam Deck y PC portátil

Dispositivos portátiles orientados a juegos de PC.

**Considerar:** pantalla pequeña, controles integrados, consumo de recursos y legibilidad de la interfaz.

## Android

Dispositivos móviles con Android.

**Considerar:** gran variedad de hardware, pantallas táctiles, rendimiento, batería y diferentes resoluciones.

## iOS / iPadOS

Dispositivos móviles y tabletas de Apple.

**Considerar:** pantalla táctil, diferentes tamaños de pantalla y requisitos de distribución.

## Navegador / Web

Videojuegos ejecutados mediante tecnologías web.

**Considerar:** compatibilidad de navegadores, tiempos de carga, almacenamiento y conectividad.

## Consola vs PC vs móvil

| Aspecto | PC | Consola | Móvil |
|---|---|---|---|
| Entrada | Teclado/mouse/control | Control | Táctil/control |
| Hardware | Muy variable | Más controlado | Muy variable |
| Pantalla | Variable | TV/monitor | Pequeña/mediana |
| Rendimiento | Variable | Predecible | Variable |
| Interfaz | Flexible | Distancia de pantalla | Táctil |

## Elección del proyecto

**Plataforma principal:**  
**¿Por qué?**

**Plataformas secundarias:**  
**¿Qué cambios requerirían?**

> [!important] Para proyectos académicos
> Si el equipo tiene tiempo limitado, comenzar con **una plataforma principal** suele reducir problemas de compatibilidad y alcance.
